package com.aman.bookhub.activity

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.aman.bookhub.R
import com.aman.bookhub.database.BookDatabase
import com.aman.bookhub.database.BookEntity
import com.aman.bookhub.util.ConnectionManager
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.squareup.picasso.Picasso
import org.json.JSONObject
import java.lang.Exception

class DescriptionActivity : AppCompatActivity() {
    lateinit var txtBookName: TextView
    lateinit var txtBookAuthor: TextView
    lateinit var txtBookRatings: TextView
    lateinit var txtBookPrice: TextView
    lateinit var txtBookImage: ImageView
    lateinit var txtBookDescription: TextView
    lateinit var btnAddToFav: Button
    lateinit var progressLayout: RelativeLayout
    lateinit var progressBar: ProgressBar
    lateinit var toolbar: Toolbar
    var book_id: String? = "100"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        txtBookName = findViewById(R.id.txtBookNameDetails)
        txtBookAuthor = findViewById(R.id.txtBookAuthorDetails)
        txtBookRatings = findViewById(R.id.txtBookRatingsDetails)
        txtBookPrice = findViewById(R.id.txtBookPriceDetails)
        txtBookImage = findViewById(R.id.imgBookDetails)
        txtBookDescription = findViewById(R.id.txtBookDescription)
        btnAddToFav = findViewById(R.id.btnAddToFavourites)
        progressBar = findViewById(R.id.progressBarDetails)
        progressBar.visibility = View.VISIBLE
        progressLayout = findViewById(R.id.progressLayoutDetails)
        progressLayout.visibility = View.VISIBLE
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Book Details"


        if (intent != null) {
            book_id = intent.getStringExtra("book_id")
        } else if (book_id == "100") {
            finish()
            Toast.makeText(
                this@DescriptionActivity,
                "Some unexpected error occured!!",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            finish()
            Toast.makeText(
                this@DescriptionActivity,
                "Some unexpected error occured!!",
                Toast.LENGTH_SHORT
            ).show()
        }

        val queue = Volley.newRequestQueue(this@DescriptionActivity)
        val url = "http://13.235.250.119/v1/book/get_book/"

        val jsonParams = JSONObject()
        jsonParams.put("book_id", book_id)
        if(ConnectionManager().checkConnectivity(this@DescriptionActivity)) {
            val jsonRequest = object : JsonObjectRequest(Request.Method.POST, url, jsonParams,
                Response.Listener {
                    try {
                        val success = it.getBoolean("success")
                        if (success) {
                            val bookJSONObject = it.getJSONObject("book_data")
                            progressLayout.visibility = View.GONE
                            val bookImageUrl = bookJSONObject.getString("image")
                            Picasso.get().load(bookJSONObject.getString("image"))
                                .error(R.drawable.default_book_cover).into(txtBookImage)
                            txtBookName.text = bookJSONObject.getString("name")
                            txtBookAuthor.text = bookJSONObject.getString("author")
                            txtBookPrice.text = bookJSONObject.getString("price")
                            txtBookRatings.text = bookJSONObject.getString("rating")
                            txtBookDescription.text = bookJSONObject.getString("description")

                            val bookEntity = BookEntity(
                                book_id?.toInt() as Int,
                                txtBookName.text.toString(),
                                txtBookAuthor.text.toString(),
                                txtBookPrice.text.toString(),
                                txtBookRatings.text.toString(),
                                txtBookDescription.text.toString(),
                                bookImageUrl
                            )

                            val checkFav = DBAsyncTask(applicationContext, bookEntity, 1).execute()
                            val isFav = checkFav.get()

                            if(isFav)
                            {
                                btnAddToFav.text = "REMOVE FROM FAVOURITES"
                                val favColor = ContextCompat.getColor(applicationContext, R.color.color_favourite)
                                btnAddToFav.setBackgroundColor(favColor)
                            }
                            else
                            {
                                btnAddToFav.text = "ADD TO FAVOURITES"
                                val favColor = ContextCompat.getColor(applicationContext, R.color.design_default_color_primary)
                                btnAddToFav.setBackgroundColor(favColor)
                            }
                                btnAddToFav.setOnClickListener {
                                    if (!(DBAsyncTask(
                                            applicationContext,
                                            bookEntity,
                                            mode = 1
                                        ).execute().get())
                                    ) {
                                        val async = DBAsyncTask(
                                            applicationContext,
                                            bookEntity,
                                            mode = 2
                                        ).execute()
                                        val result = async.get()
                                        if (result) {
                                            Toast.makeText(
                                                this@DescriptionActivity,
                                                "Book added to Favourites",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            btnAddToFav.text = "REMOVE FROM FAVOURITES"
                                            val favColor = ContextCompat.getColor(
                                                applicationContext,
                                                R.color.color_favourite
                                            )
                                            btnAddToFav.setBackgroundColor(favColor)
                                        } else {
                                            Toast.makeText(
                                                this@DescriptionActivity,
                                                "Error occured while adding the book!!",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    } else {
                                        val async = DBAsyncTask(
                                            applicationContext,
                                            bookEntity,
                                            mode = 3
                                        ).execute()
                                        val result = async.get()
                                        if (result) {
                                            Toast.makeText(
                                                this@DescriptionActivity,
                                                "Book removed from Favourites",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            btnAddToFav.text = "ADD FROM FAVOURITES"
                                            val favColor = ContextCompat.getColor(
                                                applicationContext,
                                                R.color.design_default_color_primary
                                            )
                                            btnAddToFav.setBackgroundColor(favColor)
                                        } else {
                                            Toast.makeText(
                                                this@DescriptionActivity,
                                                "Error occured while removing the book!!",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                                }
                        } else {
                            Toast.makeText(
                                this@DescriptionActivity,
                                "Some Error Occured!!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(
                            this@DescriptionActivity,
                            "Some Error Occured!!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },
                Response.ErrorListener {
                    Toast.makeText(this@DescriptionActivity, "Volley Error $it", Toast.LENGTH_SHORT)
                        .show()
                }) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-type"] = "application/json"
                    headers["token"] = "e8711d038f5bf3"
                    return headers
                }
            }
            queue.add(jsonRequest)
        }
        else
        {
            val dialog = AlertDialog.Builder(this@DescriptionActivity)
            dialog.setTitle("FAILURE")
            dialog.setMessage("Internet connection is not available!")
            dialog.setPositiveButton("Open Settings") { text, listner ->
                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                finish()
            }
            dialog.setNegativeButton("Cancel") { text, listner ->
                ActivityCompat.finishAffinity(this@DescriptionActivity)
            }
            dialog.create()
            dialog.show()
        }
    }
    class DBAsyncTask(val context: Context, val bookEntity: BookEntity, val mode: Int): AsyncTask<Void, Void, Boolean>()
    {
        val db = Room.databaseBuilder(context, BookDatabase::class.java, "book-db").build()
        override fun doInBackground(vararg params: Void?): Boolean {

            when(mode){

                1 ->
                {
                    val book: BookEntity? = db.bookDao().getEntryById(bookEntity.book_id.toString())
                    db.close()
                    return book!=null
                }
                2 ->
                {
                    db.bookDao().insertEntry(bookEntity)
                    db.close()
                    return true
                }
                3 ->
                {
                    db.bookDao().deleteEntry(bookEntity)
                    db.close()
                    return true
                }
            }
            return false
        }

    }
}