package com.aman.bookhub.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.aman.bookhub.*
import com.aman.bookhub.fragment.AboutAppFragment
import com.aman.bookhub.fragment.DashboardFragment
import com.aman.bookhub.fragment.FavouritesFragment
import com.aman.bookhub.fragment.ProfileFragment
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    lateinit var drawerlayout : DrawerLayout
    lateinit var coordinatorLayout: CoordinatorLayout
    lateinit var toolbar: Toolbar
    lateinit var frameLayout: FrameLayout
    lateinit var navigationView: NavigationView
    var previousMenuItem: MenuItem? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerlayout = findViewById(R.id.drawer_layout)
        coordinatorLayout = findViewById(R.id.coordinator_layout)
        toolbar = findViewById(R.id.toolbar)
        frameLayout = findViewById(R.id.frame_layout)
        navigationView = findViewById(R.id.navigation_view)
        setUpToolBar()
        openDashboard()

        navigationView.setNavigationItemSelectedListener {

            if(previousMenuItem!=null)
            {
                previousMenuItem?.isChecked = false
            }
            it.isCheckable = true
            it.isChecked = true
            previousMenuItem = it

            when(it.itemId)
            {
                R.id.dashboard ->
                {
                    openDashboard()
                    drawerlayout.closeDrawers()
                }
                R.id.favourites ->
                {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame_layout, FavouritesFragment())
                        .commit()
                    supportActionBar?.title = "Favourites"
                    drawerlayout.closeDrawers()
                }
                R.id.profile ->
                {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame_layout, ProfileFragment())
                        .commit()
                    supportActionBar?.title = "Profile"
                    drawerlayout.closeDrawers()
                }
                R.id.about_app ->
                {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame_layout, AboutAppFragment())
                        .commit()
                    supportActionBar?.title = "About App"
                    drawerlayout.closeDrawers()
                }
            }
            return@setNavigationItemSelectedListener true
        }
        val actionBarDrawerToggle = ActionBarDrawerToggle(this@MainActivity, drawerlayout,
            R.string.open_drawer,
            R.string.close_drawer
        )
        drawerlayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
    }
    fun setUpToolBar()
    {
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Title Toolbar"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId

        if(id == android.R.id.home)
        {
            drawerlayout.openDrawer(GravityCompat.START)
        }
        return super.onOptionsItemSelected(item)
    }

    fun openDashboard()
    {
        supportFragmentManager.beginTransaction()
            .replace(R.id.frame_layout, DashboardFragment())
            .commit()
        supportActionBar?.title = "Dashboard"
        navigationView.setCheckedItem(R.id.dashboard)
    }

    override fun onBackPressed() {
        val id = supportFragmentManager.findFragmentById(R.id.frame_layout)
        when(id)
        {
            !is DashboardFragment -> openDashboard()
            else -> super.onBackPressed()
        }
    }
}