package com.aman.bookhub.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface BookDao {

    @Insert
fun insertEntry(bookEntity: BookEntity)

@Delete
fun deleteEntry(bookEntity: BookEntity)

@Query(value = "SELECT * FROM books")
fun getAllEntry(): List<BookEntity>

@Query(value = "SELECT* FROM books WHERE book_id = :book_id")
fun getEntryById(book_id: String): BookEntity
}