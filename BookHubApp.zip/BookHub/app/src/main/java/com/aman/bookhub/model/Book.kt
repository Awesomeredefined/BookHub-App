package com.aman.bookhub.model

data class Book(
    val bookId: String,
    val bookName : String,
    val bookAuthor : String,
    val bookRatings: String,
    val bookPrice : String,
    val bookImage: String
)
